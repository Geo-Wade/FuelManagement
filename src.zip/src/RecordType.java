public enum RecordType {
    EQUIPMENT,
    OPERATOR,
    PRODUCT,
    TANK,
    FUELING_POSITION;
}
