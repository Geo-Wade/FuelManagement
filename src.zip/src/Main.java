import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        UserInterface UI = new UserInterface();
        UI.firstPrompt();
        //Handle Response to first prompt
        //take in user confirmation for authorization
        //prompt user for user number
        //check input against set for authorization
        //return username for confirmation
        //present available hoses with product descriptions
        //record user input
        //start process for pumping fuel
        //record amount of product that is input in the vehicle
        //track amount product that has been pumped
    }
}